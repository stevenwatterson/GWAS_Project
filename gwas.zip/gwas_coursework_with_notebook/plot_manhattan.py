#!/usr/bin/env python3
# plot_manhattan.py
# Usage: python3 plot_manhattan.py --assoc results.assoc --out manhattan.png
import argparse
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def manhattan(df, chr_col='CHR', bp_col='BP', p_col='P', snp_col='SNP', out='manhattan.png'):
    df = df.dropna(subset=[chr_col, bp_col, p_col])
    df['-log10p'] = -np.log10(df[p_col].replace(0, 1e-300))
    df = df.sort_values([chr_col, bp_col])
    # chromosome colors
    df['ind'] = range(len(df))
    df['chr'] = df[chr_col].astype(str)
    groups = df.groupby('chr')
    ticks = []
    labels = []
    plt.figure(figsize=(12,6))
    for i, (name, group) in enumerate(groups):
        plt.scatter(group['ind'], group['-log10p'], s=10, label=name)
        # tick at middle
        ticks.append(group['ind'].median())
        labels.append(name)
    # genome-wide significance (Bonferroni)
    bonf = 0.05 / len(df)
    plt.axhline(-np.log10(bonf), color='red', linestyle='--', linewidth=1)
    plt.xticks(ticks, labels, rotation='vertical', fontsize=8)
    plt.xlabel('Chromosome')
    plt.ylabel('-log10(p)')
    plt.title('Manhattan plot')
    plt.tight_layout()
    plt.savefig(out, dpi=150)
    print(f"Saved Manhattan plot to {out}")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--assoc', required=True, help='PLINK .assoc file from --assoc')
    parser.add_argument('--out', default='manhattan.png', help='Output image file')
    args = parser.parse_args()
    df = pd.read_csv(args.assoc, delim_whitespace=True)
    manhattan(df, out=args.out)

if __name__ == "__main__":
    main()
