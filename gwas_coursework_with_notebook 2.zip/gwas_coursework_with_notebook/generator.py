#!/usr/bin/env python3
"""Regenerate the synthetic PED/MAP dataset used in the coursework.

Usage:
    python3 generator.py --outdir ./gwas_coursework --seed 42
